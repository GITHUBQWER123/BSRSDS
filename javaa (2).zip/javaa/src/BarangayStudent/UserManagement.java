package BarangayStudent;

import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;

import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;

import com.toedter.calendar.JDateChooser;


import net.proteanit.sql.DbUtils;

import javax.swing.border.MatteBorder;
import javax.swing.JRadioButton;
import javax.imageio.ImageIO;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;

public class UserManagement extends JPanel{

	private JFrame frame;
	private JLabel date;
	private JLabel time;
	private JTextField admin;
	private JTextField fn;
	private JTextField mn;
	private JTextField ln;
	private JTextField age;
	private JTextField house;
	private JTextField barangay;
	private JTextField muni;
	private JTextField email;
	private JTextField prov;
	private JTextField con;
	private JTextField user;
	private JPasswordField pass;
	private JTable table;
	JButton btnNewButton = new JButton("UPDATE");
	Connection conn = null;
	PreparedStatement pst = null;	
	Statement st;
	ResultSet rs = null;
	
	//image
	File f = null;
	String path = null;
	private ImageIcon format = null;
	String filename= null;
	int s= 0;
	byte[]img = null;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UserManagement window = new UserManagement();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public UserManagement() {
		initialize();
		showTable();
		showTime();
		showDate();
	
	}
	public  static boolean valpass(String password) {
		String pass = "Pas";
		if(pass.length() > 4){
			
		}
		
		return false;
	}
	public void autoID() {
		
	    try {

	    	conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/barangay_student","root","student");
			 Statement pst = conn.createStatement();
		     ResultSet rs =  pst.executeQuery("select Max(AdminNo) from signup");
	         rs.next();
	        
	        rs.getString("Max(AdminNo)");
	        
	        
	        
			
			if(rs.getString("Max(AdminNo)")==null)
	        {
	            
	        	
				admin.setText("A-00001");
	        }
	        else
	        {
	            Long id = Long.parseLong(rs.getString("Max(AdminNo)").substring(2,rs.getString("Max(AdminNo)").length()));
	            id++;
	            admin.setText("A-" + String.format("%05d", id));
	        }

	    } catch (SQLException ex) {
	      
	    }
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		setBounds(0, 0, 1187, 844);
		setVisible(true);
		setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(245, 245, 220));
		panel.setBounds(0, 0, 1187, 855);
		add(panel);
		panel.setLayout(null);
		
		JPanel panel_1_1 = new JPanel();
		panel_1_1.setLayout(null);
		panel_1_1.setBorder(null);
		panel_1_1.setBackground(new Color(255, 218, 185));
		panel_1_1.setBounds(0, 0, 1187, 79);
		panel.add(panel_1_1);
		
		JLabel lblNewLabel_3 = new JLabel("USER MANAGEMENT");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setForeground(Color.BLACK);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_3.setBounds(364, 34, 423, 45);
		panel_1_1.add(lblNewLabel_3);
		
		JLabel lblNewLabel_1_1 = new JLabel("Date :");
		ImageIcon datee = new ImageIcon(this.getClass().getResource("/date.png"));
		Image date1 = datee.getImage();	
		Image date2 = date1.getScaledInstance(36,24, Image.SCALE_SMOOTH);
		ImageIcon date3 = new ImageIcon(date2);
		lblNewLabel_1_1.setIcon(date3);
		lblNewLabel_1_1.setBounds(1036, 11, 36, 24);
		panel_1_1.add(lblNewLabel_1_1);
		
		 date = new JLabel("08/11/2022");
		date.setForeground(Color.BLACK);
		date.setFont(new Font("Tahoma", Font.BOLD, 12));
		date.setBounds(1075, 11, 91, 24);
		panel_1_1.add(date);
		
		 time = new JLabel("New label");
		time.setForeground(Color.BLACK);
		time.setFont(new Font("Tahoma", Font.BOLD, 12));
		time.setBounds(1075, 40, 91, 24);
		panel_1_1.add(time);
		
		JLabel lblNewLabel_1_4 = new JLabel("Time :");
		ImageIcon timee = new ImageIcon(this.getClass().getResource("/time.png"));
		Image time1 = timee.getImage();	
		Image time2 = time1.getScaledInstance(36,24, Image.SCALE_SMOOTH);
		ImageIcon time3 = new ImageIcon(time2);
		lblNewLabel_1_4.setIcon(time3);
		lblNewLabel_1_4.setBounds(1036, 40, 36, 24);
		panel_1_1.add(lblNewLabel_1_4);
		
		JLabel lblNewLabel_3_1 = new JLabel("BARANGAY STUDENT DATABASE");
		lblNewLabel_3_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3_1.setForeground(Color.BLACK);
		lblNewLabel_3_1.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblNewLabel_3_1.setBounds(213, 0, 708, 46);
		panel_1_1.add(lblNewLabel_3_1);
		
		JLabel lblNewLabel_1 = new JLabel("New label");
		ImageIcon bar = new ImageIcon(this.getClass().getResource("/barangay.png"));
		Image bar1 = bar.getImage();	
		Image bar2 = bar1.getScaledInstance(98,79, Image.SCALE_SMOOTH);
		ImageIcon bar3 = new ImageIcon(bar2);
		lblNewLabel_1.setIcon(bar3);
		lblNewLabel_1.setBounds(149, 0, 98, 79);
		panel_1_1.add(lblNewLabel_1);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(245, 222, 179));
		panel_1.setBounds(48, 113, 1088, 454);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_4 = new JLabel("Admin No");
		lblNewLabel_4.setBounds(47, 22, 97, 31);
		panel_1.add(lblNewLabel_4);
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 16));
		
		admin = new JTextField();
		admin.setEnabled(false);
		admin.setBounds(45, 46, 198, 31);
		panel_1.add(admin);
		admin.setColumns(10);
		
		fn = new JTextField();
		fn.setEnabled(false);
		fn.setBounds(47, 112, 198, 31);
		panel_1.add(fn);
		fn.setColumns(10);
		
		JLabel lblNewLabel_4_1 = new JLabel("Firstname");
		lblNewLabel_4_1.setBounds(49, 88, 97, 31);
		panel_1.add(lblNewLabel_4_1);
		lblNewLabel_4_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		
		mn = new JTextField();
		mn.setEnabled(false);
		mn.setBounds(276, 112, 198, 31);
		panel_1.add(mn);
		mn.setColumns(10);
		
		JLabel lblNewLabel_4_2 = new JLabel("Middlename");
		lblNewLabel_4_2.setBounds(278, 88, 114, 31);
		panel_1.add(lblNewLabel_4_2);
		lblNewLabel_4_2.setFont(new Font("Tahoma", Font.BOLD, 16));
		
		ln = new JTextField();
		ln.setEnabled(false);
		ln.setBounds(500, 112, 198, 31);
		panel_1.add(ln);
		ln.setColumns(10);
		
		JLabel lblNewLabel_4_3 = new JLabel("Lastname");
		lblNewLabel_4_3.setBounds(502, 88, 97, 31);
		panel_1.add(lblNewLabel_4_3);
		lblNewLabel_4_3.setFont(new Font("Tahoma", Font.BOLD, 16));
		
		JLabel lblNewLabel_4_4 = new JLabel("Birthdate");
		lblNewLabel_4_4.setBounds(47, 154, 97, 31);
		panel_1.add(lblNewLabel_4_4);
		lblNewLabel_4_4.setFont(new Font("Tahoma", Font.BOLD, 16));
		
		age = new JTextField();
		age.setEnabled(false);
		age.setBounds(276, 178, 198, 31);
		panel_1.add(age);
		age.setColumns(10);
		
		JLabel lblNewLabel_4_5 = new JLabel("Age");
		lblNewLabel_4_5.setBounds(278, 154, 97, 31);
		panel_1.add(lblNewLabel_4_5);
		lblNewLabel_4_5.setFont(new Font("Tahoma", Font.BOLD, 16));
		
		JLabel lblNewLabel_4_6 = new JLabel("Gender");
		lblNewLabel_4_6.setBounds(502, 154, 97, 31);
		panel_1.add(lblNewLabel_4_6);
		lblNewLabel_4_6.setFont(new Font("Tahoma", Font.BOLD, 16));
		
		house = new JTextField();
		house.setEnabled(false);
		house.setBounds(47, 244, 198, 31);
		panel_1.add(house);
		house.setColumns(10);
		
		JLabel lblNewLabel_4_7 = new JLabel("HouseNo/Street");
		lblNewLabel_4_7.setBounds(49, 220, 132, 31);
		panel_1.add(lblNewLabel_4_7);
		lblNewLabel_4_7.setFont(new Font("Tahoma", Font.BOLD, 16));
		
		barangay = new JTextField();
		barangay.setEnabled(false);
		barangay.setBounds(276, 244, 198, 31);
		panel_1.add(barangay);
		barangay.setColumns(10);
		
		JLabel lblNewLabel_4_8 = new JLabel("Barangay");
		lblNewLabel_4_8.setBounds(278, 220, 97, 31);
		panel_1.add(lblNewLabel_4_8);
		lblNewLabel_4_8.setFont(new Font("Tahoma", Font.BOLD, 16));
		
		muni = new JTextField();
		muni.setEnabled(false);
		muni.setBounds(500, 244, 198, 31);
		panel_1.add(muni);
		muni.setColumns(10);
		
		JLabel lblNewLabel_4_9 = new JLabel("Municipality");
		lblNewLabel_4_9.setBounds(502, 220, 114, 31);
		panel_1.add(lblNewLabel_4_9);
		lblNewLabel_4_9.setFont(new Font("Tahoma", Font.BOLD, 16));
		
		email = new JTextField();
		email.setEnabled(false);
		email.setBounds(500, 310, 198, 31);
		panel_1.add(email);
		email.setColumns(10);
		
		JLabel lblNewLabel_4_7_1 = new JLabel("Province");
		lblNewLabel_4_7_1.setBounds(49, 286, 132, 31);
		panel_1.add(lblNewLabel_4_7_1);
		lblNewLabel_4_7_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		
		prov = new JTextField();
		prov.setEnabled(false);
		prov.setBounds(47, 310, 198, 31);
		panel_1.add(prov);
		prov.setColumns(10);
		
		con = new JTextField();
		con.setEnabled(false);
		con.setBounds(276, 310, 198, 31);
		panel_1.add(con);
		con.setColumns(10);
		
		JLabel lblNewLabel_4_9_1 = new JLabel("Email");
		lblNewLabel_4_9_1.setBounds(502, 286, 97, 31);
		panel_1.add(lblNewLabel_4_9_1);
		lblNewLabel_4_9_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		
		JLabel lblNewLabel_4_8_1 = new JLabel("Contact No");
		lblNewLabel_4_8_1.setBounds(278, 286, 97, 31);
		panel_1.add(lblNewLabel_4_8_1);
		lblNewLabel_4_8_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		
		JLabel lblNewLabel_4_7_2 = new JLabel("Position");
		lblNewLabel_4_7_2.setBounds(47, 352, 132, 31);
		panel_1.add(lblNewLabel_4_7_2);
		lblNewLabel_4_7_2.setFont(new Font("Tahoma", Font.BOLD, 16));
		
		user = new JTextField();
		user.setEnabled(false);
		user.setBounds(274, 376, 198, 31);
		panel_1.add(user);
		user.setColumns(10);
		
		JLabel lblNewLabel_4_9_2 = new JLabel("Password");
		lblNewLabel_4_9_2.setBounds(500, 352, 97, 31);
		panel_1.add(lblNewLabel_4_9_2);
		lblNewLabel_4_9_2.setFont(new Font("Tahoma", Font.BOLD, 16));
		
		JLabel lblNewLabel_4_8_2 = new JLabel("Username");
		lblNewLabel_4_8_2.setBounds(276, 352, 97, 31);
		panel_1.add(lblNewLabel_4_8_2);
		lblNewLabel_4_8_2.setFont(new Font("Tahoma", Font.BOLD, 16));
		
		pass = new JPasswordField();
		pass.setEnabled(false);
		pass.setBounds(500, 376, 183, 31);
		panel_1.add(pass);
		
		JComboBox gender = new JComboBox();
		gender.setEnabled(false);
		gender.setBounds(500, 178, 198, 31);
		panel_1.add(gender);
		gender.setModel(new DefaultComboBoxModel(new String[] {"Select", "Male", "Female"}));
		gender.setToolTipText("Select");
		
		JDateChooser bd = new JDateChooser();
		bd.setEnabled(false);
		bd.setBounds(47, 178, 198, 31);
		panel_1.add(bd);
		
		JComboBox pos = new JComboBox();
		pos.setEnabled(false);
		pos.setModel(new DefaultComboBoxModel(new String[] {"Select", "Barangay Captain", "SK Chairman", "Secretary", "Kagawad"}));
		pos.setBounds(47, 376, 198, 31);
		panel_1.add(pos);
		
		JLabel imgDis = new JLabel("");
		imgDis.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				JFileChooser chooser = new JFileChooser();
				chooser.showOpenDialog(null);
				File f = chooser.getSelectedFile();
				filename = f.getAbsolutePath();
				ImageIcon ImageIcon = new ImageIcon(new ImageIcon(filename).getImage().getScaledInstance(imgDis.getWidth(),imgDis.getHeight(),Image.SCALE_SMOOTH));
				imgDis.setIcon(ImageIcon);
				
				
				try {
					File image = new File(filename);
					FileInputStream fis = new FileInputStream(image);
					ByteArrayOutputStream bos = new ByteArrayOutputStream();
					byte [] buf = new byte[1204];
					for(int readNum;(readNum=fis.read(buf))!=-1;){
			        bos.write(buf,0,readNum);
					}
					img = bos.toByteArray();
				}catch(Exception ev) {
					
				}
			}
		});
		imgDis.setBounds(744, 132, 290, 227);
		panel_1.add(imgDis);
		imgDis.setBorder(new MatteBorder(2, 2, 2, 2, (Color) new Color(0, 0, 0)));
		
		JRadioButton rdbtnNewRadioButton = new JRadioButton("New radio button");
		rdbtnNewRadioButton.setBounds(679, 376, 20, 31);
		panel_1.add(rdbtnNewRadioButton);
		rdbtnNewRadioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (rdbtnNewRadioButton.isSelected()) {
					pass.setEchoChar((char)0);
				}else {
					pass.setEchoChar('*');
				}
					
			}	
			
		});
		rdbtnNewRadioButton.setBackground(new Color(245, 222, 179));
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(47, 636, 1085, 183);
		panel.add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				btnNewButton.setEnabled(true);
				int i = table.getSelectedRow();
		  		TableModel model = table.getModel();
		  		admin.setText(model.getValueAt(i, 0).toString());
		  		fn.setText(model.getValueAt(i, 1).toString());
		  		mn.setText(model.getValueAt(i, 2).toString());
		  		ln.setText(model.getValueAt(i, 3).toString());
		  		try {
		  			Date d = new SimpleDateFormat("yyyy-MM-dd").parse((String)model.getValueAt(i,4));
		  			bd.setDate(d);
		  			
		  		}catch(Exception eee) {
		  			
		  		}
		  		age.setText(model.getValueAt(i, 5).toString());
		  		String gen = model.getValueAt(i, 6).toString();
		  		switch(gen) {
		  		case "Male":
		  			gender.setSelectedIndex(0);
		  			break;
		  		case "Female":
		  			gender.setSelectedIndex(1);
		  			break;
		  		}
		  		house.setText(model.getValueAt(i, 7).toString());
		  		barangay.setText(model.getValueAt(i, 8).toString());
		  		muni.setText(model.getValueAt(i, 9).toString());
		  		prov.setText(model.getValueAt(i, 10).toString());
		  		con.setText(model.getValueAt(i, 11).toString());
		  		email.setText(model.getValueAt(i, 12).toString());
		  		String position = model.getValueAt(i, 13).toString();
		  		switch(position) {
		  			case "Barangay Captain":
		  				pos.setSelectedIndex(0);
		  			break;
		  			case "SK Chairman":
		  				pos.setSelectedIndex(1);
		  			break;	
		  			case "Secretary":
		  				pos.setSelectedIndex(2);
		  				break;
		  			case "Kagawad":
		  				pos.setSelectedIndex(3);
		  				break;
		  		}
		  		user.setText(model.getValueAt(i, 14).toString());
		  		pass.setText(model.getValueAt(i, 15).toString());
		  		if(table.getValueAt(i, 16) != null){
		  		    try {               
		  		         byte[] byteArray = (byte[]) table.getValueAt(i, 16);
		  		         ByteArrayInputStream bais = new ByteArrayInputStream(byteArray);
		  		         BufferedImage bImg = ImageIO.read(bais);
		  		         ImageIcon icon = new ImageIcon(bImg.getScaledInstance(imgDis.getWidth(), imgDis.getHeight(), Image.SCALE_SMOOTH));
		  		         imgDis.setIcon(icon);
		  		         bais.close();
		  		    } catch (Exception ee) {
		  		         JOptionPane.showMessageDialog(null, ee.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		  		    }
		  		}else{
		  		    imgDis.setText("No Photo Available");
		  		}
		  		
		  		
			}
		});
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
					"AdminNo", "Firstname", "Middlename", "Lastname", "Birthdate", "Age", "Gender", "HouseNoStreet", "Barangay", "Municipality", "Province", "ContactNo", "Email", "Position", "Username", "Password", "Image", "Date"
			}
		));
		scrollPane.setViewportView(table);
		
		
		btnNewButton.setEnabled(false);
		ImageIcon update = new ImageIcon(this.getClass().getResource("/update.png"));
		Image update1 = update.getImage();	
		Image update2= update1.getScaledInstance(40, 40 ,Image.SCALE_SMOOTH);
		ImageIcon update3 = new ImageIcon(update2);
		btnNewButton.setIcon(update3);
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 17));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				admin.setEnabled(true);
				fn.setEnabled(true);
				mn.setEnabled(true);
				ln.setEnabled(true);
				bd.setEnabled(true);
				age.setEnabled(true);
				gender.setEnabled(true);
				house.setEnabled(true);
				barangay.setEnabled(true);
				muni.setEnabled(true);
				prov.setEnabled(true);
				con.setEnabled(true);
				email.setEnabled(true);
				pos.setEnabled(true);
				user.setEnabled(true);
				pass.setEnabled(true);
			}
		});
		btnNewButton.setBounds(205, 581, 156, 44);
		panel.add(btnNewButton);
		
		JButton btnDelete = new JButton("DELETE");
		ImageIcon delete = new ImageIcon(this.getClass().getResource("/delete.png"));
		Image delete1 = delete.getImage();	
		Image delete2= delete1.getScaledInstance(40, 40 ,Image.SCALE_SMOOTH);
		ImageIcon delete3 = new ImageIcon(delete2);
		btnDelete.setIcon(delete3);
		btnDelete.setFont(new Font("Tahoma", Font.BOLD, 17));
		btnDelete.setBounds(371, 581, 139, 44);
		panel.add(btnDelete);
		
		JButton btnSave = new JButton("SAVE");
		ImageIcon save = new ImageIcon(this.getClass().getResource("/save.png"));
		Image save1 = save.getImage();	
		Image save2= save1.getScaledInstance(40, 40 ,Image.SCALE_SMOOTH);
		ImageIcon save3 = new ImageIcon(save2);
		btnSave.setIcon(save3);
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String sql1 = "Select * from signup where AdminNo=?";
					conn	 = DriverManager.getConnection("jdbc:mysql://localhost:3306/barangay_student","root","student");
					pst = conn.prepareStatement(sql1);
					pst.setString(1, admin.getText());
					ResultSet rs1 = pst.executeQuery();
					if(rs1.next()) {
						try{
						 	conn	 = DriverManager.getConnection("jdbc:mysql://localhost:3306/barangay_student","root","student");
				 			String sql = "update signup set Firstname=?,Middlename=?,Lastname=?,Birthdate=?,Age=?,Gender=?,HouseNoStreet=?,Barangay=?,Municipality=?,Province=?,ContactNo=?,Email=?,Position=?,Username=?,Password=?,Image=? where AdminNo=?";
				 			pst = conn.prepareStatement(sql);
				 			pst.setString(17, admin.getText());
							pst.setString(1, fn.getText());
							pst.setString(2, mn.getText());
							pst.setString(3, ln.getText());
							SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
							String date1 = sdf.format(bd.getDate());
							pst.setString(4,date1);
							pst.setString(5, age.getText());
							pst.setString(6, (String) gender.getSelectedItem());
							pst.setString(7, house.getText());
							pst.setString(8, barangay.getText());
							pst.setString(9, muni.getText());
							pst.setString(10, prov.getText());
							pst.setString(11, con.getText());
							pst.setString(12, email.getText());
							pst.setString(13,(String) pos.getSelectedItem());
							pst.setString(14, user.getText());
							pst.setString(15, pass.getText());
							pst.setBytes(16, img);
							pst.execute();
							JOptionPane.showMessageDialog(null, "Successfully Update");
							showTable();
						}catch(Exception ee) {
							JOptionPane.showMessageDialog(null, ee);
						}
					}
					else {
						
						conn	 = DriverManager.getConnection("jdbc:mysql://localhost:3306/barangay_student","root","student");
						String sql = "INSERT INTO signup(AdminNo,Firstname,Middlename,Lastname,Birthdate,Age,Gender,HouseNoStreet,Barangay,Municipality,Province,ContactNo,Email,Position,Username,Password,Image,Date)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
				  		try {
							pst = conn.prepareStatement(sql);
							pst.setString(1, admin.getText());
							pst.setString(2, fn.getText());
							pst.setString(3, mn.getText());
							pst.setString(4, ln.getText());
							SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
							String date1 = sdf.format(bd.getDate());
							pst.setString(5,date1);
							pst.setString(6, age.getText());
							pst.setString(7, (String) gender.getSelectedItem());
							pst.setString(8, house.getText());
							pst.setString(9, barangay.getText());
							pst.setString(10, muni.getText());
							pst.setString(11, prov.getText());
							pst.setString(12, con.getText());
							pst.setString(13, email.getText());
							pst.setString(14,(String) pos.getSelectedItem());
							pst.setString(15, user.getText());
							pst.setString(16, pass.getText());
							pst.setBytes(17, img);
							pst.setString(18,date.getText());
							
							
				            pst.executeUpdate();
				            
				  				
				  				JOptionPane.showMessageDialog(null,"Successfully Add");
				  				showTable();
						  } catch (Exception ex) {
							  JOptionPane.showMessageDialog(null,ex);
								
				  	          
						  }
					}
				}catch(Exception e1) {
					
				}
				
			}
		});
		btnSave.setFont(new Font("Tahoma", Font.BOLD, 17));
		btnSave.setBounds(993, 581, 139, 44);
		panel.add(btnSave);
		
		JButton btnAdd = new JButton("ADD");
		ImageIcon add = new ImageIcon(this.getClass().getResource("/add.png"));
		Image add1 = add.getImage();	
		Image add2= add1.getScaledInstance(40, 40 ,Image.SCALE_SMOOTH);
		ImageIcon add3 = new ImageIcon(add2);
		btnAdd.setIcon(add3);
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				autoID();
				admin.setEditable(false);
				fn.setEnabled(true);
				mn.setEnabled(true);
				ln.setEnabled(true);
				bd.setEnabled(true);
				age.setEnabled(true);
				gender.setEnabled(true);
				house.setEnabled(true);
				barangay.setEnabled(true);
				muni.setEnabled(true);
				prov.setEnabled(true);
				con.setEnabled(true);
				email.setEnabled(true);
				pos.setEnabled(true);
				user.setEnabled(true);
				pass.setEnabled(true);
				
				
				fn.setText("");
				mn.setText("");
				ln.setText("");
				bd.setDate(null);
				age.setText("");
				gender.setSelectedIndex(0);
				house.setText("");
				barangay.setText("");
				muni.setText("");
				prov.setText("");
				con.setText("");
				email.setText("");
				pos.setSelectedIndex(0);
				user.setText("");
				pass.setText("");
				
				
			}
		});
		btnAdd.setFont(new Font("Tahoma", Font.BOLD, 17));
		btnAdd.setBounds(58, 581, 139, 44);
		panel.add(btnAdd);
	}
	
	private void showTable() {
			
		
		
			String sql ="Select * from signup";
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
			 	conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/barangay_student","root","student");
				pst = conn.prepareStatement(sql);
				rs = pst.executeQuery();
				table.setModel(DbUtils.resultSetToTableModel(rs));		
				}
			catch(Exception e)
			{

		}finally {
			try {
				
				rs.close();
				pst.close();
			}catch(Exception e) {
				
			}
		}
		}
	public void showDate() {
		Date d = new Date();
		SimpleDateFormat  s = new SimpleDateFormat("dd/MM/yyyy");
		String dat = s.format(d);
		date.setText(dat);
	}

	public void showTime() {
		new Timer (0,new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent ae) {
			Date d = new Date();
			SimpleDateFormat  s = new SimpleDateFormat("hh:mm:ss aa");
			String tim = s.format(d);
			time.setText(tim);
				
			}
		}).start();
		
	}
	}
