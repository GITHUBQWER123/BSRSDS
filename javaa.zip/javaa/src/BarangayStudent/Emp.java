package BarangayStudent;



public class Emp {

	
	public static String UserPos;
	
}
